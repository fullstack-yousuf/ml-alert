from flask import Flask, jsonify
from firebase_service import get_latest_reading, send_alert
from model import detect
from datetime import datetime

app = Flask(__name__)

@app.route("/check", methods=["GET"])
def check():
    data = get_latest_reading()
    if not data:
        return jsonify({"status": "no data"})

    glucose = data["glucose"]
    heart_rate = data["heart_rate"]

    is_anomaly = detect(glucose, heart_rate)

    if is_anomaly:
        send_alert({
            "glucose": glucose,
            "heart_rate": heart_rate,
            "time": datetime.now().isoformat(),
            "message": "⚠️ Anomaly Detected"
        })

    return jsonify({
        "glucose": glucose,
        "heart_rate": heart_rate,
        "anomaly": is_anomaly
    })

if __name__ == "__main__":
    app.run(debug=True)
