import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate("serviceAccountKey.json")

firebase_admin.initialize_app(cred, {
    "databaseURL": "https://diabetes-monitoring-fyp-default-rtdb.firebaseio.com/"
})

def get_latest_reading():
    ref = db.reference("readings")
    data = ref.order_by_key().limit_to_last(1).get()
    if data:
        return list(data.values())[0]
    return None

def send_alert(alert_data):
    alert_ref = db.reference("alerts")
    alert_ref.push(alert_data)
