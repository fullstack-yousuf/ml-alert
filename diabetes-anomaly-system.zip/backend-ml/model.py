import numpy as np
from sklearn.ensemble import IsolationForest

model = IsolationForest(contamination=0.1)

def train():
    X = np.array([
        [100, 80],
        [110, 85],
        [95, 78],
        [300, 150]
    ])
    model.fit(X)

train()

def detect(glucose, heart_rate):
    prediction = model.predict([[glucose, heart_rate]])
    return prediction[0] == -1
